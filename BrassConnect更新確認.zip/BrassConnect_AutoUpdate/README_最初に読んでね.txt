BrassConnect 自動更新用プロジェクト

目的
- 既存の Workers URL を維持しながら、GitHub にコードを更新すると Cloudflare が自動デプロイする構成にする。
- 部活データ（予定・お知らせ・やる曲等）は、アプリ内の管理機能と Firebase 同期で更新する。

重要
- このZIPをアップロードしただけでは、公開中サイトは変わりません。
- Cloudflare / GitHubへの接続と、既存Workerへの紐づけはアカウント所有者の操作が必要です。
- このパッケージの Worker 名はURLから推定した「quiet-violet-5844」です。Cloudflareダッシュボード上のWorker名が異なる場合、wrangler.jsonc の name を実際の名前に合わせてください。
- 本番反映前に、プレビューでログイン、Firebase同期、出欠権限、やる曲の追加・削除を確認してください。

手順
1. ZIPを展開する。
2. GitHubで新しいリポジトリを作成し、このフォルダの中身（public、src、wrangler.jsonc、README）をアップロードする。
3. Cloudflare Dashboard > Workers & Pages > 対象Worker「quiet-violet-5844」> Settings > Builds > Connect からGitHubリポジトリを接続する。
4. Root directory は空欄（リポジトリ直下）、Build command は空欄、Deploy command は `npx wrangler deploy` にする。
5. 接続後、GitHub上でコミットを更新するとCloudflareが自動デプロイする。
6. 既存URL https://quiet-violet-5844.i17278986.workers.dev/ を開いて確認する。

アプリのデータ更新
- やる曲、予定、お知らせなどはアプリ内の管理者画面から編集し、Firebase経由で同期する仕組みです。
- アプリのコード・デザイン・機能変更は、GitHubの public/index.html を更新してコミットすると自動デプロイされます。
